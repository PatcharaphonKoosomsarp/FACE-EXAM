import React, { useState } from 'react';
import AuthScreen from './components/AuthScreen';
import TeacherDashboard from './components/TeacherDashboard';
import StudentDashboard from './components/StudentDashboard';
import { User, UserRole, Room, Exam } from './types';

// Initial Mock Data
const INITIAL_ROOMS: Room[] = [
    { 
      id: '101', 
      name: 'Lab 401', 
      rows: 6, 
      cols: 6,
      ipMapping: {
        '1-1': '192.168.1.101',
        '1-2': '192.168.1.102'
      }
    },
    { id: '102', name: 'Lecture Hall 1', rows: 10, cols: 8 },
];

const INITIAL_EXAMS: Exam[] = [
    {
        id: '201',
        roomId: '101',
        subjectCode: '06016317',
        subjectName: 'Advanced Web Programming',
        section: '1',
        date: '2023-11-15',
        startTime: '09:00',
        endTime: '12:00',
        createdBy: 'Ajarn. Somchai',
        blockedResources: [
            { id: 'r1', name: 'ChatGPT', type: 'WEB_APP' },
            { id: 'r2', name: 'StackOverflow', type: 'WEB_APP' }
        ]
    }
];

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [rooms, setRooms] = useState<Room[]>(INITIAL_ROOMS);
  const [exams, setExams] = useState<Exam[]>(INITIAL_EXAMS);

  const handleLogout = () => {
    setUser(null);
  };

  // --- Room CRUD ---
  const handleAddRoom = (newRoom: Room) => {
    setRooms(prev => [...prev, newRoom]);
  };

  const handleUpdateRoom = (updatedRoom: Room) => {
    setRooms(prev => prev.map(r => r.id === updatedRoom.id ? updatedRoom : r));
  };

  const handleDeleteRoom = (roomId: string) => {
    // Check constraints
    const isUsed = exams.some(e => e.roomId === roomId);
    if (isUsed) {
        const usedExam = exams.find(e => e.roomId === roomId);
        alert(`ไม่สามารถลบห้องสอบนี้ได้ เนื่องจากถูกใช้งานในวิชา ${usedExam?.subjectCode} ${usedExam?.subjectName}\nกรุณาลบตารางสอบที่เกี่ยวข้องก่อน`);
        return;
    }

    if (window.confirm("คุณแน่ใจหรือไม่ที่จะลบห้องสอบนี้?")) {
        setRooms(prev => prev.filter(r => r.id !== roomId));
    }
  };

  // --- Exam CRUD ---
  const handleAddExam = (newExam: Exam) => {
    setExams(prev => [...prev, newExam]);
  };

  const handleUpdateExam = (updatedExam: Exam) => {
    setExams(prev => prev.map(e => e.id === updatedExam.id ? updatedExam : e));
  };

  const handleDeleteExam = (examId: string) => {
    if (window.confirm("คุณแน่ใจหรือไม่ที่จะลบตารางสอบนี้?")) {
        setExams(prev => prev.filter(e => e.id !== examId));
    }
  };

  const handleUpdateUser = (updatedUser: User) => {
      setUser(updatedUser);
  }

  if (!user) {
    return <AuthScreen onLogin={setUser} />;
  }

  return (
    <div className="min-h-screen bg-gray-100">
        {/* Simple Top Bar */}
        <div className="bg-white shadow-sm border-b px-6 py-3 flex justify-between items-center sticky top-0 z-40">
            <div className="font-bold text-[#E35205] text-sm md:text-lg flex items-center">
                <span className="bg-[#E35205] text-white p-1 rounded mr-2 text-xs flex-shrink-0">KMUTNB</span>
                <span className="truncate max-w-[200px] md:max-w-none" title="FACIAL RECOGNITION AND RESOURCE MONITORING SYSTEM FOR LAB EXAMS">
                  FACIAL RECOGNITION AND RESOURCE MONITORING SYSTEM FOR LAB EXAMS
                </span>
            </div>
            <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                    <img src={user.avatarUrl} alt="Avatar" className="w-8 h-8 rounded-full bg-gray-200" />
                    <div className="hidden md:block text-right leading-tight">
                        <div className="text-sm font-semibold">{user.name}</div>
                        <div className="text-xs text-gray-500">{user.role}</div>
                    </div>
                </div>
                <button 
                    onClick={handleLogout}
                    className="text-sm text-gray-500 hover:text-red-500 border-l pl-4"
                >
                    ออกจากระบบ
                </button>
            </div>
        </div>

        {/* Role Based Routing */}
        <main className="py-6">
            {user.role === UserRole.TEACHER && (
                <TeacherDashboard 
                    user={user} 
                    rooms={rooms} 
                    exams={exams} 
                    onAddRoom={handleAddRoom}
                    onUpdateRoom={handleUpdateRoom}
                    onDeleteRoom={handleDeleteRoom}
                    onAddExam={handleAddExam}
                    onUpdateExam={handleUpdateExam}
                    onDeleteExam={handleDeleteExam}
                />
            )}
            {user.role === UserRole.STUDENT && (
                <StudentDashboard 
                    user={user}
                    exams={exams}
                    rooms={rooms}
                    onUpdateUser={handleUpdateUser}
                />
            )}
            {user.role === UserRole.GUEST && (
                <div className="text-center p-20 text-red-500 font-bold">
                    Access Denied. Invalid Role.
                </div>
            )}
        </main>
    </div>
  );
};

export default App;