import React, { useState } from 'react';
import { User, UserRole } from '../types';
import { ScanFace, FileCheck } from 'lucide-react';

interface AuthScreenProps {
  onLogin: (user: User) => void;
}

const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin }) => {
  const [showAccountChooser, setShowAccountChooser] = useState(false);

  const handleLoginSelection = (email: string) => {
    let role = UserRole.GUEST;
    if (email.endsWith('@itm.kmutnb.ac.th')) {
      role = UserRole.TEACHER;
    } else if (email.endsWith('@email.kmutnb.ac.th')) {
      role = UserRole.STUDENT;
    }

    const mockUser: User = {
      email,
      name: email.split('@')[0],
      role,
      isFaceRegistered: false,
      avatarUrl: `https://ui-avatars.com/api/?name=${email.split('@')[0]}&background=random`
    };

    onLogin(mockUser);
  };

  const GoogleIcon = () => (
    <svg className="w-6 h-6 mr-3" viewBox="0 0 24 24">
      <path
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
        fill="#4285F4"
      />
      <path
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
        fill="#34A853"
      />
      <path
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.26.81-.58z"
        fill="#FBBC05"
      />
      <path
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
        fill="#EA4335"
      />
    </svg>
  );

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4 font-sans">
      <div className="bg-white p-10 md:p-12 rounded-[2rem] shadow-xl w-full max-w-2xl border border-gray-100 flex flex-col items-center relative overflow-hidden">
        {/* Decorative background element */}
        <div className="absolute top-0 left-0 w-full h-3 bg-gradient-to-r from-[#E35205] to-orange-400"></div>

        <div className="text-center mb-10 mt-6">
          {/* Combined Logo Container */}
          <div className="relative bg-orange-50 p-8 rounded-full w-44 h-44 flex items-center justify-center mx-auto mb-8 shadow-sm ring-8 ring-orange-50/50 group hover:scale-105 transition-transform duration-500">
            {/* Primary Icon: Scan Face */}
            <ScanFace className="w-24 h-24 text-[#E35205] stroke-[1.5]" />
            
            {/* Secondary Badge: Exam/Check */}
            <div className="absolute bottom-2 right-2 bg-white rounded-full p-3 shadow-lg border-2 border-orange-100 flex items-center justify-center">
               <FileCheck className="w-10 h-10 text-green-600 stroke-[2]" />
            </div>
          </div>
          
          <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-800 leading-snug mb-3">
            ระบบสแกนใบหน้าและติดตามการใช้ทรัพยากรคอมพิวเตอร์สำหรับการสอบในห้องปฏิบัติการ
          </h1>
          
          <p className="text-sm text-gray-400 font-bold uppercase tracking-widest mt-2">
            Facial Recognition and Resource Monitoring System for Lab Exams
          </p>
        </div>

        {/* Conditions Box */}
        <div className="w-full bg-gray-50 border border-gray-200 rounded-2xl p-6 md:p-8 mb-8 relative mt-4">
           <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-white px-5 py-1 text-sm md:text-base text-gray-500 font-medium rounded-full border border-gray-100 shadow-sm">
             เงื่อนไขการเข้าใช้งาน
           </div>
           <div className="text-base md:text-lg text-gray-700 space-y-4 flex flex-col items-center pt-2">
              <div className="flex items-center w-full justify-center">
                  <span className="w-2.5 h-2.5 bg-orange-500 rounded-full mr-3 shrink-0"></span>
                  <span>นักศึกษา: <span className="font-mono text-gray-900 bg-white border border-gray-200 px-3 py-1 rounded-md text-sm md:text-base ml-2 font-medium">@email.kmutnb.ac.th</span></span>
              </div>
              <div className="flex items-center w-full justify-center">
                  <span className="w-2.5 h-2.5 bg-gray-700 rounded-full mr-3 shrink-0"></span>
                  <span>อาจารย์: <span className="font-mono text-gray-900 bg-white border border-gray-200 px-3 py-1 rounded-md text-sm md:text-base ml-2 font-medium">@itm.kmutnb.ac.th</span></span>
              </div>
           </div>
        </div>

        <button
          onClick={() => setShowAccountChooser(true)}
          className="w-full max-w-sm bg-white text-gray-700 font-bold text-lg py-4 px-6 border-2 border-gray-200 rounded-full hover:bg-gray-50 hover:border-gray-300 hover:shadow-lg transition-all flex items-center justify-center group transform hover:-translate-y-0.5"
        >
          <GoogleIcon />
          <span>Sign in with Google</span>
        </button>

        {/* Account Chooser Modal */}
        {showAccountChooser && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 animate-in fade-in duration-200 backdrop-blur-sm">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden transform transition-all scale-100">
              <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                <span className="font-semibold text-gray-700 text-lg">Choose an account</span>
                <button 
                  onClick={() => setShowAccountChooser(false)} 
                  className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-200 text-gray-500 transition text-lg"
                >
                  ✕
                </button>
              </div>
              <div className="p-2 space-y-1">
                <button 
                  onClick={() => handleLoginSelection('student@email.kmutnb.ac.th')}
                  className="w-full flex items-center p-4 hover:bg-blue-50 rounded-xl transition text-left group border border-transparent hover:border-blue-100"
                >
                  <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-4 font-bold text-xl">
                    S
                  </div>
                  <div>
                    <div className="font-bold text-lg text-gray-900 group-hover:text-blue-700">Student Account</div>
                    <div className="text-sm text-gray-500">student@email.kmutnb.ac.th</div>
                  </div>
                </button>
                
                <button 
                  onClick={() => handleLoginSelection('teacher@itm.kmutnb.ac.th')}
                  className="w-full flex items-center p-4 hover:bg-orange-50 rounded-xl transition text-left group border border-transparent hover:border-orange-100"
                >
                  <div className="w-12 h-12 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center mr-4 font-bold text-xl">
                    T
                  </div>
                  <div>
                    <div className="font-bold text-lg text-gray-900 group-hover:text-orange-700">Teacher Account</div>
                    <div className="text-sm text-gray-500">teacher@itm.kmutnb.ac.th</div>
                  </div>
                </button>
              </div>
              <div className="p-3 bg-gray-50 text-xs text-center text-gray-400">
                Simulation Mode
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AuthScreen;