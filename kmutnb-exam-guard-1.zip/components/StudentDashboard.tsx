import React, { useState } from 'react';
import { User, Exam, Room } from '../types';
import { Camera, Calendar, Clock, MapPin, AlertTriangle, Monitor } from 'lucide-react';
import FaceRegistration from './FaceRegistration';
import FaceVerification from './FaceVerification';

interface StudentDashboardProps {
  user: User;
  exams: Exam[];
  rooms: Room[];
  onUpdateUser: (updatedUser: User) => void;
}

const StudentDashboard: React.FC<StudentDashboardProps> = ({ user, exams, rooms, onUpdateUser }) => {
  const [showFaceReg, setShowFaceReg] = useState(false);
  const [verifyingExam, setVerifyingExam] = useState<Exam | null>(null);
  const [activeExam, setActiveExam] = useState<Exam | null>(null);

  const handleFaceRegComplete = () => {
    setShowFaceReg(false);
    onUpdateUser({ ...user, isFaceRegistered: true });
    alert('ลงทะเบียนใบหน้าสำเร็จ!');
  };

  const handleEnterExam = (exam: Exam) => {
      setVerifyingExam(exam);
  };

  const handleVerified = () => {
      if (verifyingExam) {
          setActiveExam(verifyingExam);
          setVerifyingExam(null);
      }
  };

  if (activeExam) {
      return (
          <div className="min-h-screen bg-gray-900 text-white flex flex-col">
              <header className="bg-gray-800 p-4 flex justify-between items-center border-b border-gray-700">
                  <div className="flex items-center gap-3">
                      <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                      <h1 className="font-bold text-lg">กำลังสอบ: {activeExam.subjectName} ({activeExam.subjectCode})</h1>
                  </div>
                  <button onClick={() => setActiveExam(null)} className="text-sm bg-red-600 hover:bg-red-700 px-3 py-1 rounded">ออกจากการสอบ</button>
              </header>
              <div className="flex-1 p-8 flex items-center justify-center">
                  <div className="text-center max-w-2xl">
                      <Monitor className="w-24 h-24 text-gray-700 mx-auto mb-6" />
                      <h2 className="text-3xl font-bold mb-4">เข้าสู่โหมดห้องสอบปลอดภัย</h2>
                      <div className="bg-gray-800 p-6 rounded-xl border border-gray-700 text-left mb-6">
                          <h3 className="text-orange-500 font-bold mb-3 flex items-center"><AlertTriangle className="w-5 h-5 mr-2"/> กฎการใช้ทรัพยากร</h3>
                          <ul className="space-y-2 text-sm text-gray-300">
                              {activeExam.blockedResources.length > 0 ? activeExam.blockedResources.map(r => (
                                  <li key={r.id} className="flex items-center">
                                      <span className="w-2 h-2 bg-red-500 rounded-full mr-2"></span>
                                      ห้ามใช้: <span className="text-white font-medium ml-1">{r.name}</span> <span className="text-xs text-gray-500 ml-2">({r.type})</span>
                                  </li>
                              )) : <li>ไม่มีการจำกัดทรัพยากรพิเศษ</li>}
                          </ul>
                          <p className="mt-4 text-xs text-gray-500">*ระบบกำลังติดตามการใช้งาน หากพบการละเมิดจะแจ้งเตือนผู้คุมสอบทันที</p>
                      </div>
                      <div className="text-green-400 text-sm">สถานะ: ใบหน้าอยู่ในกล้อง | ทรัพยากรปกติ</div>
                  </div>
              </div>
          </div>
      );
  }

  return (
    <div className="container mx-auto p-4 max-w-5xl">
      <header className="mb-8 flex justify-between items-end border-b pb-4">
        <div>
            <h1 className="text-3xl font-bold text-gray-800">แผงควบคุมนักศึกษา</h1>
            <p className="text-gray-500">สวัสดี, {user.name}</p>
        </div>
        <div className="flex items-center">
            <div className={`px-3 py-1 rounded-full text-xs font-semibold flex items-center ${user.isFaceRegistered ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                {user.isFaceRegistered ? 'ลงทะเบียนใบหน้าแล้ว' : 'ยังไม่ลงทะเบียนใบหน้า'}
            </div>
        </div>
      </header>

      {!user.isFaceRegistered ? (
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-8 text-center">
              <Camera className="w-16 h-16 text-[#E35205] mx-auto mb-4" />
              <h2 className="text-xl font-bold text-gray-800 mb-2">กรุณาลงทะเบียนใบหน้าก่อนเริ่มใช้งาน</h2>
              <p className="text-gray-600 mb-6 max-w-md mx-auto">ระบบจำเป็นต้องเก็บข้อมูลใบหน้าเพื่อใช้ในการยืนยันตัวตนก่อนเข้าห้องสอบ เพื่อความปลอดภัยและความโปร่งใส</p>
              <button 
                onClick={() => setShowFaceReg(true)}
                className="bg-[#E35205] text-white px-8 py-3 rounded-lg font-bold hover:bg-orange-700 transition shadow-lg"
              >
                  เริ่มลงทะเบียนใบหน้า
              </button>
          </div>
      ) : (
          <div>
              <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center"><Calendar className="w-5 h-5 mr-2"/> ตารางสอบของคุณ</h2>
              {exams.length === 0 ? (
                  <p className="text-gray-500 bg-gray-50 p-8 rounded-lg text-center">ยังไม่มีตารางสอบในขณะนี้</p>
              ) : (
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                      {exams.map(exam => {
                          const room = rooms.find(r => r.id === exam.roomId);
                          return (
                              <div key={exam.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition">
                                  <div className="bg-gray-50 p-4 border-b">
                                      <h3 className="font-bold text-lg text-gray-800">{exam.subjectCode}</h3>
                                      <p className="text-gray-600 truncate">{exam.subjectName}</p>
                                  </div>
                                  <div className="p-4 space-y-3 text-sm">
                                      <div className="flex items-center text-gray-600">
                                          <MapPin className="w-4 h-4 mr-2" />
                                          ห้อง {room?.name || 'Unknown'}
                                      </div>
                                      <div className="flex items-center text-gray-600">
                                          <Calendar className="w-4 h-4 mr-2" />
                                          {exam.date}
                                      </div>
                                      <div className="flex items-center text-gray-600">
                                          <Clock className="w-4 h-4 mr-2" />
                                          {exam.startTime} - {exam.endTime}
                                      </div>
                                      <div className="pt-2">
                                          <button 
                                            onClick={() => handleEnterExam(exam)}
                                            className="w-full bg-[#E35205] text-white py-2 rounded font-medium hover:bg-orange-700 transition"
                                          >
                                              เข้าห้องสอบ
                                          </button>
                                      </div>
                                  </div>
                              </div>
                          );
                      })}
                  </div>
              )}
          </div>
      )}

      {showFaceReg && (
          <FaceRegistration 
            onComplete={handleFaceRegComplete} 
            onCancel={() => setShowFaceReg(false)} 
          />
      )}

      {verifyingExam && (
          <FaceVerification 
            user={user}
            exam={verifyingExam}
            onVerified={handleVerified}
            onCancel={() => setVerifyingExam(null)}
          />
      )}
    </div>
  );
};

export default StudentDashboard;