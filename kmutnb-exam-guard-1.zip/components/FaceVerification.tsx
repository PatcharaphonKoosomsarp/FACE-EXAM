import React, { useEffect, useRef, useState, useCallback } from 'react';
import { User, Exam } from '../types';
import { ShieldCheck, Loader2, AlertTriangle, RefreshCw, CameraOff, Lock } from 'lucide-react';

interface FaceVerificationProps {
    user: User;
    exam: Exam;
    onVerified: () => void;
    onCancel: () => void;
}

const FaceVerification: React.FC<FaceVerificationProps> = ({ user, exam, onVerified, onCancel }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const [status, setStatus] = useState<'SCANNING' | 'SUCCESS' | 'FAILED'>('SCANNING');
    const [errorMessage, setErrorMessage] = useState<string | null>(null);
    const [errorType, setErrorType] = useState<'PERMISSION' | 'NOT_FOUND' | 'IN_USE' | 'GENERIC' | null>(null);

    const startCamera = useCallback(async () => {
        setStatus('SCANNING');
        setErrorMessage(null);
        setErrorType(null);
        let stream: MediaStream | null = null;

        try {
            stream = await navigator.mediaDevices.getUserMedia({ video: true });
            if (videoRef.current) {
                videoRef.current.srcObject = stream;
            }
            // Simulate verification delay
            setTimeout(() => {
                setStatus('SUCCESS');
                setTimeout(() => {
                    onVerified();
                }, 1500);
            }, 3000);
        } catch (err: any) {
            console.error("Camera access error:", err);
            setStatus('FAILED');
            
            if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
                setErrorType('PERMISSION');
                setErrorMessage("กรุณาอนุญาตสิทธิ์การใช้กล้องในเบราว์เซอร์");
            } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
                setErrorType('NOT_FOUND');
                setErrorMessage("ไม่พบอุปกรณ์กล้องบนเครื่องนี้");
            } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
                setErrorType('IN_USE');
                setErrorMessage("กล้องกำลังถูกใช้งานโดยโปรแกรมอื่น");
            } else {
                setErrorType('GENERIC');
                setErrorMessage("เกิดข้อผิดพลาด: " + err.message);
            }
        }
    }, [onVerified]);

    useEffect(() => {
        startCamera();
        return () => {
            if (videoRef.current && videoRef.current.srcObject) {
                const stream = videoRef.current.srcObject as MediaStream;
                stream.getTracks().forEach(t => t.stop());
            }
        };
    }, [startCamera]);

    return (
        <div className="fixed inset-0 bg-gray-900/90 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-white rounded-2xl overflow-hidden shadow-2xl max-w-md w-full animate-in zoom-in-95 duration-200">
                <div className="bg-white p-5 border-b flex justify-between items-center">
                    <div>
                        <h3 className="font-bold text-gray-800 text-lg flex items-center">
                            <ShieldCheck className="w-5 h-5 mr-2 text-[#E35205]" />
                            ยืนยันตัวตน
                        </h3>
                        <p className="text-xs text-gray-500 mt-1">วิชา: {exam.subjectName}</p>
                    </div>
                    {status !== 'SUCCESS' && (
                        <button onClick={onCancel} className="text-gray-400 hover:text-gray-600 transition">✕</button>
                    )}
                </div>
                
                <div className="relative aspect-[4/3] bg-black group">
                    {status !== 'FAILED' && (
                        <video ref={videoRef} autoPlay muted playsInline className="w-full h-full object-cover transform scale-x-[-1]" />
                    )}
                    
                    {/* Scanning Overlay */}
                    {status === 'SCANNING' && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                            <div className="text-center">
                                <div className="relative">
                                    <div className="absolute inset-0 rounded-full border-4 border-t-[#E35205] border-r-transparent border-b-transparent border-l-transparent animate-spin"></div>
                                    <div className="bg-white/10 backdrop-blur-md rounded-full p-4">
                                        <Loader2 className="w-8 h-8 text-white/80" />
                                    </div>
                                </div>
                                <p className="text-white font-medium mt-4 drop-shadow-md">กำลังตรวจสอบใบหน้า...</p>
                            </div>
                            <div className="absolute top-0 w-full h-1 bg-gradient-to-r from-transparent via-[#E35205] to-transparent animate-[scan_2s_linear_infinite]" style={{ animationName: 'scan' }}></div>
                        </div>
                    )}
                    
                    {/* Success Overlay */}
                    {status === 'SUCCESS' && (
                        <div className="absolute inset-0 bg-green-500 flex items-center justify-center flex-col animate-in fade-in duration-300">
                             <div className="bg-white rounded-full p-4 mb-4 shadow-lg animate-in zoom-in duration-300">
                                <ShieldCheck className="w-12 h-12 text-green-500" />
                             </div>
                             <p className="text-white text-2xl font-bold">ยืนยันตัวตนสำเร็จ</p>
                             <p className="text-green-100 text-sm mt-2">กำลังเข้าสู่ห้องสอบ...</p>
                        </div>
                    )}

                    {/* Failed Overlay */}
                    {status === 'FAILED' && (
                        <div className="absolute inset-0 bg-gray-900 flex items-center justify-center flex-col p-8 text-center z-10">
                             <div className="bg-red-500/20 p-4 rounded-full mb-4">
                                 {errorType === 'PERMISSION' ? <Lock className="w-10 h-10 text-red-500" /> : 
                                  errorType === 'IN_USE' ? <CameraOff className="w-10 h-10 text-red-500" /> :
                                  <AlertTriangle className="w-10 h-10 text-red-500" />}
                             </div>
                             <p className="text-white text-xl font-bold mb-2">เข้าถึงกล้องไม่ได้</p>
                             <p className="text-gray-400 text-sm mb-6 leading-relaxed">
                                {errorMessage || 'ไม่สามารถเข้าถึงกล้องได้'}
                                {errorType === 'PERMISSION' && <span className="block mt-2 text-xs text-red-300 bg-red-900/30 p-2 rounded">เคล็ดลับ: คลิกที่ไอคอนแม่กุญแจ 🔒 บนแถบที่อยู่ แล้วเลือก "อนุญาต" (Allow)</span>}
                             </p>
                             
                             <div className="flex gap-3 w-full">
                                <button 
                                    onClick={onCancel} 
                                    className="flex-1 bg-gray-700 text-white px-4 py-2.5 rounded-lg font-medium hover:bg-gray-600 transition"
                                >
                                    ยกเลิก
                                </button>
                                <button 
                                    onClick={startCamera} 
                                    className="flex-1 bg-white text-gray-900 px-4 py-2.5 rounded-lg font-bold hover:bg-gray-200 transition flex items-center justify-center"
                                >
                                    <RefreshCw className="w-4 h-4 mr-2" /> ลองใหม่
                                </button>
                             </div>
                        </div>
                    )}
                </div>
                
                {/* Footer Info */}
                <div className="p-4 bg-gray-50 text-center flex justify-between text-xs text-gray-500">
                    <span>Student: {user.name}</span>
                    <span>Status: {status === 'SCANNING' ? 'Verifying...' : status}</span>
                </div>
            </div>
            <style>{`@keyframes scan { 0% { top: 0; opacity: 0; } 50% { opacity: 1; } 100% { top: 100%; opacity: 0; } }`}</style>
        </div>
    );
};

export default FaceVerification;