import React, { useState, useRef, useEffect } from 'react';
import { Camera, RefreshCw, CheckCircle, Smartphone, Monitor, AlertTriangle, Lock, VideoOff } from 'lucide-react';
import { FaceRegistrationStep } from '../types';

interface FaceRegistrationProps {
  onComplete: () => void;
  onCancel: () => void;
}

const stepsData: FaceRegistrationStep[] = [
  { id: '1', instruction: 'หน้าตรง', description: 'มองตรงไปที่กล้อง', isCompleted: false },
  { id: '2', instruction: 'หลับตา-ลืมตา', description: 'หลับตาลงช้าๆ แล้วลืมตา', isCompleted: false },
  { id: '3', instruction: 'หันซ้าย', description: 'หันหน้าไปทางซ้ายช้าๆ', isCompleted: false },
  { id: '4', instruction: 'หันขวา', description: 'หันหน้าไปทางขวาช้าๆ', isCompleted: false },
  { id: '5', instruction: 'เงยหน้า-ก้มหน้า', description: 'ขยับศีรษะขึ้นและลง', isCompleted: false },
  { id: '6', instruction: 'ใบหน้าเข้าใกล้', description: 'ขยับใบหน้าเข้าใกล้กล้อง', isCompleted: false },
];

const FaceRegistration: React.FC<FaceRegistrationProps> = ({ onComplete, onCancel }) => {
  const [method, setMethod] = useState<'WEBCAM' | 'QR' | null>(null);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [steps, setSteps] = useState(stepsData);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isCapturing, setIsCapturing] = useState(false);
  const [qrSimulateProgress, setQrSimulateProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [errorType, setErrorType] = useState<'PERMISSION' | 'NOT_FOUND' | 'IN_USE' | 'GENERIC' | null>(null);
  const [retryCount, setRetryCount] = useState(0);

  // Webcam Logic
  useEffect(() => {
    let stream: MediaStream | null = null;

    const startCamera = async () => {
      if (method === 'WEBCAM' && !isCapturing) {
        try {
          setError(null);
          setErrorType(null);
          stream = await navigator.mediaDevices.getUserMedia({ video: true });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        } catch (err: any) {
          console.error("Camera error:", err);
          
          if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
             setErrorType('PERMISSION');
             setError("สิทธิ์การเข้าถึงกล้องถูกปฏิเสธ");
          } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
             setErrorType('NOT_FOUND');
             setError("ไม่พบอุปกรณ์กล้อง");
          } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
             setErrorType('IN_USE');
             setError("กล้องถูกใช้งานโดยโปรแกรมอื่น");
          } else {
             setErrorType('GENERIC');
             setError("ไม่สามารถเข้าถึงกล้องได้: " + err.message);
          }
        }
      }
    };

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [method, isCapturing, retryCount]);

  // Simulate Step Progression
  useEffect(() => {
    if (method === 'WEBCAM' && currentStepIndex < steps.length && !error) {
      const timer = setTimeout(() => {
        setSteps(prev => {
          const newSteps = [...prev];
          newSteps[currentStepIndex].isCompleted = true;
          return newSteps;
        });
        
        if (currentStepIndex < steps.length - 1) {
            setCurrentStepIndex(prev => prev + 1);
        } else {
            // All done
            setTimeout(() => {
                onComplete();
            }, 1000);
        }
      }, 3000); // Simulate 3 seconds per step
      return () => clearTimeout(timer);
    }
  }, [method, currentStepIndex, steps.length, onComplete, error]);

  // QR Simulation Logic
  useEffect(() => {
    if (method === 'QR') {
        const interval = setInterval(() => {
            setQrSimulateProgress(prev => {
                if (prev >= 100) {
                    clearInterval(interval);
                    setTimeout(onComplete, 500);
                    return 100;
                }
                return prev + 2; // fills in ~2.5 seconds
            });
        }, 50);
        return () => clearInterval(interval);
    }
  }, [method, onComplete]);

  const handleRetry = () => {
      setError(null);
      setErrorType(null);
      setRetryCount(prev => prev + 1);
  };

  if (!method) {
    return (
      <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-2xl p-8 max-w-lg w-full text-center animate-in zoom-in-95 duration-200">
          <h2 className="text-2xl font-bold mb-6 text-gray-800">เลือกวิธีการลงทะเบียนใบหน้า</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button 
                onClick={() => setMethod('WEBCAM')}
                className="flex flex-col items-center justify-center p-6 border-2 border-gray-200 rounded-xl hover:border-[#E35205] hover:bg-orange-50 transition group"
            >
                <Monitor className="w-12 h-12 mb-3 text-gray-400 group-hover:text-[#E35205] transition-colors" />
                <span className="font-semibold text-gray-700">ใช้กล้องเว็บแคม</span>
                <span className="text-xs text-gray-500 mt-1">บนอุปกรณ์นี้</span>
            </button>
            <button 
                onClick={() => setMethod('QR')}
                className="flex flex-col items-center justify-center p-6 border-2 border-gray-200 rounded-xl hover:border-[#E35205] hover:bg-orange-50 transition group"
            >
                <Smartphone className="w-12 h-12 mb-3 text-gray-400 group-hover:text-[#E35205] transition-colors" />
                <span className="font-semibold text-gray-700">สแกน QR Code</span>
                <span className="text-xs text-gray-500 mt-1">เปิดกล้องผ่านมือถือ</span>
            </button>
          </div>
          <button onClick={onCancel} className="mt-8 text-gray-500 hover:text-gray-800 underline text-sm transition">ยกเลิกการลงทะเบียน</button>
        </div>
      </div>
    );
  }

  if (method === 'QR') {
      return (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-8 max-w-md w-full text-center">
                <h2 className="text-xl font-bold mb-4">สแกนเพื่อเปิดกล้องมือถือ</h2>
                <div className="bg-gray-100 w-48 h-48 mx-auto mb-4 rounded-lg flex items-center justify-center relative overflow-hidden border border-gray-200">
                     {/* Pseudo QR Code */}
                     <div className="grid grid-cols-6 grid-rows-6 gap-1 w-32 h-32 opacity-80">
                         {Array.from({length: 36}).map((_, i) => (
                             <div key={i} className={`bg-black ${Math.random() > 0.5 ? 'opacity-100' : 'opacity-0'}`}></div>
                         ))}
                     </div>
                     {/* Scan Line */}
                     <div className="absolute top-0 left-0 w-full h-1 bg-red-500 shadow-[0_0_10px_rgba(255,0,0,0.8)] animate-[scan_2s_ease-in-out_infinite]" style={{ animationName: 'scan' }}></div>
                     <style>{`@keyframes scan { 0% { top: 0; } 100% { top: 100%; } }`}</style>
                </div>
                <p className="text-sm text-gray-600 mb-4">กำลังเชื่อมต่อกับอุปกรณ์มือถือ...</p>
                <div className="w-full bg-gray-200 rounded-full h-2.5 mb-1">
                    <div className="bg-[#E35205] h-2.5 rounded-full transition-all duration-300" style={{ width: `${qrSimulateProgress}%` }}></div>
                </div>
                <p className="text-xs text-gray-400">{qrSimulateProgress}%</p>
                <button onClick={() => setMethod(null)} className="mt-6 text-sm text-gray-500 hover:text-gray-900">ย้อนกลับ</button>
            </div>
        </div>
      );
  }

  return (
    <div className="fixed inset-0 bg-gray-900 flex flex-col items-center justify-center z-50">
      <div className="w-full max-w-5xl bg-white rounded-2xl overflow-hidden shadow-2xl flex flex-col md:flex-row h-[85vh]">
        
        {/* Camera View */}
        <div className="relative bg-black flex-1 flex items-center justify-center overflow-hidden">
          {error ? (
              <div className="flex flex-col items-center text-white p-8 text-center max-w-md animate-in fade-in zoom-in-95">
                  <div className="bg-red-500/20 p-5 rounded-full mb-6 ring-1 ring-red-500/50">
                      {errorType === 'PERMISSION' ? <Lock className="w-12 h-12 text-red-500" /> : 
                       errorType === 'IN_USE' ? <VideoOff className="w-12 h-12 text-red-500" /> :
                       <AlertTriangle className="w-12 h-12 text-red-500" />}
                  </div>
                  <h3 className="text-2xl font-bold mb-2 text-red-400">{error}</h3>
                  
                  <div className="bg-gray-800/80 rounded-lg p-4 mb-8 text-sm text-gray-300 border border-gray-700">
                      {errorType === 'PERMISSION' && (
                          <p>กรุณากดที่ไอคอน 🔒 หรือ 📷 บนแถบที่อยู่ (Address Bar) ของเบราว์เซอร์ แล้วเลือก <strong>"อนุญาต" (Allow)</strong> หรือ <strong>"รีเซ็ตการอนุญาต"</strong> แล้วกดปุ่มลองใหม่อีกครั้ง</p>
                      )}
                      {errorType === 'IN_USE' && (
                          <p>กล้องอาจกำลังถูกใช้งานโดยโปรแกรมอื่น (เช่น Zoom, Google Meet) กรุณาปิดโปรแกรมเหล่านั้นแล้วลองใหม่อีกครั้ง</p>
                      )}
                      {errorType === 'NOT_FOUND' && (
                          <p>ไม่พบอุปกรณ์กล้อง กรุณาตรวจสอบการเชื่อมต่อสาย USB หรือไดรเวอร์ของกล้อง</p>
                      )}
                      {errorType === 'GENERIC' && (
                          <p>เกิดข้อผิดพลาดที่ไม่ทราบสาเหตุ กรุณารีเฟรชหน้าเว็บหรือเปลี่ยนเบราว์เซอร์</p>
                      )}
                  </div>

                  <div className="flex gap-4">
                    <button 
                        onClick={() => setMethod(null)} 
                        className="px-6 py-2 rounded-full font-medium text-gray-400 hover:text-white hover:bg-white/10 transition"
                    >
                        ย้อนกลับ
                    </button>
                    <button 
                        onClick={handleRetry} 
                        className="bg-[#E35205] text-white px-8 py-2 rounded-full font-bold hover:bg-orange-600 transition shadow-lg flex items-center"
                    >
                        <RefreshCw className="w-4 h-4 mr-2" /> ลองใหม่อีกครั้ง
                    </button>
                  </div>
              </div>
          ) : (
              <>
                <video 
                    ref={videoRef} 
                    autoPlay 
                    playsInline 
                    muted 
                    className="w-full h-full object-cover transform scale-x-[-1]"
                />
                
                {/* Overlay UI */}
                <div className="absolute top-4 left-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm flex items-center z-20 backdrop-blur-sm border border-white/10">
                    <div className="w-2 h-2 bg-red-500 rounded-full mr-2 animate-pulse"></div>
                    Live Face Detection
                </div>
                
                {/* Face Box Overlay (Static) */}
                <div className="absolute w-72 h-96 border-2 border-white/40 rounded-[50%] top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 shadow-[0_0_0_9999px_rgba(0,0,0,0.7)] z-10 pointer-events-none">
                    <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-12 text-white text-center w-64">
                        <h3 className="font-bold text-2xl drop-shadow-md mb-1">{steps[currentStepIndex].instruction}</h3>
                        <p className="text-sm font-light opacity-90 drop-shadow">{steps[currentStepIndex].description}</p>
                    </div>
                    {/* Corner Markers */}
                    <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1 w-1 h-2 bg-[#E35205]"></div>
                    <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1 w-1 h-2 bg-[#E35205]"></div>
                    <div className="absolute top-1/2 left-0 transform -translate-x-1 -translate-y-1/2 w-2 h-1 bg-[#E35205]"></div>
                    <div className="absolute top-1/2 right-0 transform translate-x-1 -translate-y-1/2 w-2 h-1 bg-[#E35205]"></div>
                </div>
              </>
          )}
        </div>

        {/* Sidebar Instructions */}
        <div className="w-full md:w-80 bg-gray-50 p-6 overflow-y-auto border-l border-gray-200">
            <h3 className="font-bold text-lg mb-6 text-gray-800 flex items-center">
                <Camera className="w-5 h-5 mr-2 text-[#E35205]"/>
                ขั้นตอนการลงทะเบียน
            </h3>
            <div className="space-y-4 relative before:absolute before:left-5 before:top-4 before:bottom-4 before:w-0.5 before:bg-gray-200">
                {steps.map((step, index) => (
                    <div key={step.id} className={`relative pl-4 flex items-start p-3 rounded-xl transition-all duration-300 ${index === currentStepIndex ? 'bg-white shadow-md scale-105 z-10 ring-1 ring-orange-100' : 'opacity-60'}`}>
                        {/* Status Indicator */}
                        <div className="absolute -left-[5px] top-1/2 transform -translate-y-1/2 bg-gray-50 p-1">
                             {step.isCompleted ? (
                                <div className="w-4 h-4 bg-green-500 rounded-full border-2 border-white shadow-sm flex items-center justify-center">
                                    <CheckCircle className="w-3 h-3 text-white"/>
                                </div>
                            ) : (
                                <div className={`w-4 h-4 rounded-full border-2 bg-white ${index === currentStepIndex ? 'border-[#E35205] scale-125' : 'border-gray-300'}`}></div>
                            )}
                        </div>

                        <div className="ml-2">
                            <h4 className={`font-bold text-sm ${index === currentStepIndex ? 'text-[#E35205]' : 'text-gray-700'}`}>{step.instruction}</h4>
                            <p className="text-xs text-gray-500 mt-0.5">{step.description}</p>
                        </div>
                    </div>
                ))}
            </div>
            <button onClick={onCancel} className="mt-8 w-full py-3 text-gray-500 text-sm border border-gray-200 bg-white rounded-xl hover:bg-gray-50 hover:text-red-500 font-medium transition shadow-sm">
                ยกเลิก
            </button>
        </div>
      </div>
    </div>
  );
};

export default FaceRegistration;